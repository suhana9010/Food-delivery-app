package com.Zdevelopors.ruby.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.Zdevelopors.ruby.ItemSelect;

import com.Zdevelopors.ruby.R;

import java.util.ArrayList;


public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private RecyclerView mrecyclerview;
    private RecyclerViewAdapter madapter;
    private RecyclerView.LayoutManager mlayoutManager;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(HomeFragment.this).get(HomeViewModel.class);
        final View root = inflater.inflate(R.layout.fragment_home,container,false);

        final ArrayList<Hotel_card> hotelcardList = new ArrayList<>();
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Hotel Nakshatra","Biryani,South Indian", (float) 3.6,R.drawable.ic_bookmark_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Anand Tiffins","Dosa,Idli", (float) 4.3,R.drawable.ic_bookmark_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Mehfil-E-Mandi","Mandi Biryani, Irani", (float) 4.5,R.drawable.ic_bookmark_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Paradise Restaurant","Biryani, South Indian", (float) 4.2,R.drawable.ic_bookmark_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Pista House","Cakes, Sweets, Pastries", (float) 4.8,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Kamat Restaurant","Vegetarian", (float) 3.9,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Bawarchi Restaurant","Biryani, Kebabs", (float) 4.7,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Barbeque Nation","Buffet, Chinese", (float)4.0,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Kfc","Chicken,FastFood", (float) 3.9,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"cafe bahar & restaurant","Biryani", (float) 4.0,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Cafe Coffee Day","Beverages", (float) 4.1,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Pizza Hut","Pizza, Beverages", (float) 3.8,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Mc Donalds","Burgers, Beverages", (float) 4.5,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Baskin 31 Robbins","Desserts", (float) 4.9,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Subbayya Gaari Hotel","Vegetarian, Local Dishes", (float) 3.8,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Haiking","Cakes ,Burgers", (float)4.0,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Ram Ki Bandi","Idli, Dosa", (float) 3.6,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Vennela FastFood","Chinese, FastFood", (float) 3.0,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Hotel Nakshatra","Biryani", (float) 3.6,R.drawable.ic_bookmark_border_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Hotel Nakshatra","Biryani", (float) 3.6,R.drawable.ic_bookmark_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Hotel Nakshatra","Biryani", (float) 3.6,R.drawable.ic_bookmark_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Hotel Nakshatra","Biryani", (float) 3.6,R.drawable.ic_bookmark_black_24dp));
        hotelcardList.add(new Hotel_card(R.drawable.foodpic,"Hotel Nakshatra","Biryani", (float) 3.6,R.drawable.ic_bookmark_black_24dp));

        mrecyclerview = root.findViewById(R.id.All_Restraunts);
        mrecyclerview.setHasFixedSize(true);
        madapter = new RecyclerViewAdapter(hotelcardList);
        try {
            mrecyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        }
        catch (Exception e)
        {
            Log.d("Ruby",e.toString());
        }

        mrecyclerview.setAdapter(madapter);
        madapter.setOnItemClickListener(new RecyclerViewAdapter.OnItemClickListener() {
            @Override
            public void OnItemClick(int position) {
                Hotel_card SelectedItem = hotelcardList.get(position);
                Intent intent = new Intent(getContext(), ItemSelect.class);

                intent.putExtra("Hotel_pic",SelectedItem.getRestrauntImage());
                intent.putExtra("Hotel_Name",SelectedItem.getRestrauntName());
                intent.putExtra("Hotel_Tags",SelectedItem.getTags());
                intent.putExtra("Hotel_Rating",SelectedItem.getRating());

                startActivity(intent);
            }

            @Override
            public void OnBookmarkClicked(int position) {
                hotelcardList.get(position).IsBookmarked();
                madapter.notifyItemChanged(position);
            }
        });
        return root;
    }
}
