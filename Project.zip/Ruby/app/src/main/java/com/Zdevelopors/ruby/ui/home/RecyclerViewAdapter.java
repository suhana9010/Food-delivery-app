package com.Zdevelopors.ruby.ui.home;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.RecyclerView;

import com.Zdevelopors.ruby.R;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private ArrayList<Hotel_card>  mCardList;
    private OnItemClickListener mListener;


    public interface OnItemClickListener{
        void OnItemClick(int position);
        void OnBookmarkClicked(int position);
    }
    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView mimageView;
        public TextView mTextView1;
        public TextView mTextView2;
        public TextView mTextView3;
        public ImageView mIsBookmarked;
        public ViewHolder(@NonNull final View itemView, final OnItemClickListener listener) {
            super(itemView);
            mimageView = itemView.findViewById(R.id.cardImage);
            mTextView1 = itemView.findViewById(R.id.Restraunt_name);
            mTextView2 = itemView.findViewById(R.id.Tags);
            mTextView3 = itemView.findViewById(R.id.Rating);
            mIsBookmarked = itemView.findViewById(R.id.is_bookmarked);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener != null) {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION)
                            listener.OnItemClick(position);
                    }

                }
            });

            mIsBookmarked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener != null) {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION)
                            listener.OnBookmarkClicked(position);
                    }
                }
            });

        }
    }
    public RecyclerViewAdapter(ArrayList<Hotel_card> hotelcardArrayList)
    {
        mCardList = hotelcardArrayList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_hotel_card,parent,false);
        return new ViewHolder(v,mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Hotel_card currentItem = mCardList.get(position);
        holder.mimageView.setImageResource(currentItem.getRestrauntImage());
        holder.mTextView1.setText(currentItem.getRestrauntName());
        holder.mTextView2.setText(currentItem.getTags());
        holder.mTextView3.setText(String.valueOf(currentItem.getRating()));
        holder.mIsBookmarked.setImageResource(currentItem.getIsBookmarked());
    }



    @Override
    public int getItemCount() {
        return mCardList.size();
    }
}
