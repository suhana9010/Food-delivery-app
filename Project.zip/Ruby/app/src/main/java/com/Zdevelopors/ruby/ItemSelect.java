package com.Zdevelopors.ruby;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.Zdevelopors.ruby.ui.home.RecyclerViewAdapter;

import java.util.ArrayList;
import java.util.Objects;

public class ItemSelect extends AppCompatActivity {

    private TextView Restraunt_Name;
    private ImageView Restraunt_Image;
    private TextView Restraunt_Tags;
    private TextView Restraunt_Rating;
    private RecyclerView mrecyclerview;
    private ItemViewAdapter madapter;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_select);

        Restraunt_Name = findViewById(R.id.Restraunt_Name);
        Restraunt_Image = findViewById(R.id.Restraunt_Image);
        Restraunt_Tags = findViewById(R.id.Restraunt_Tags);
        Restraunt_Rating = findViewById(R.id.Restraunt_Rating);
        Restraunt_Name.setText(getIntent().getStringExtra("Hotel_Name"));
        Restraunt_Tags.setText(getIntent().getStringExtra("Hotel_Tags"));
        Restraunt_Image.setImageResource(getIntent().getIntExtra("Hotel_pic",230));
        Restraunt_Rating.setText(String.valueOf(getIntent().getFloatExtra("Hotel_Rating",30)));
        //Hotel rating is stored as a string

        final ArrayList<Item_Card> itemcardList = new ArrayList<>();
        for(int i = 1; i <= 5; i++)
        {
            itemcardList.add(new Item_Card(R.drawable.only_veg,"Item "+String.valueOf(i),i*57, "Description of Item" + String.valueOf(i)));
        }
        for(int i = 6; i <= 10; i++)
        {
            itemcardList.add(new Item_Card(R.drawable.only_nonveg,"Item "+String.valueOf(i),i*98, "Description of Item" + String.valueOf(i)));
        }
        mrecyclerview = findViewById(R.id.All_Items);
        mrecyclerview.setHasFixedSize(true);
        madapter = new ItemViewAdapter(itemcardList);
        try {
            mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        }
        catch (Exception e)
        {
            Log.d("Ruby",e.toString());
        }
        mrecyclerview.setAdapter(madapter);
    }

}
