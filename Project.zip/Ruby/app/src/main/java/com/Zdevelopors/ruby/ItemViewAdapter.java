package com.Zdevelopors.ruby;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemViewAdapter extends RecyclerView.Adapter<ItemViewAdapter.ViewHolder> {

    private ArrayList<Item_Card> mCardList;
    private OnItemClickListener mListener;

    public interface OnItemClickListener{
        void OnItemClick(int position);
    }
    public void setOnItemClickListener(OnItemClickListener listener){ mListener = listener; }
    public static class ViewHolder extends RecyclerView.ViewHolder{

        public ImageView mimageView;
        public TextView mTextView1;
        public TextView mTextView2;
        public TextView mTextView3;
        public ViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            mimageView = itemView.findViewById(R.id.veg_nonveg);
            mTextView1 = itemView.findViewById(R.id.Item_name);
            mTextView2 = itemView.findViewById(R.id.Item_description);
            mTextView3 = itemView.findViewById(R.id.cost);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(listener != null) {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION)
                            listener.OnItemClick(position);
                    }

                }
            });
        }
    }
    public ItemViewAdapter(ArrayList<Item_Card> itemCardArrayList)
    {
        mCardList = itemCardArrayList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_item_card,parent,false);
        return new ViewHolder(v,mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item_Card currentItem = mCardList.get(position);
        try {
            holder.mimageView.setImageResource(currentItem.getVeg_or_Nonveg());
            holder.mTextView3.setText(String.valueOf(currentItem.getCost()));
        }
        catch (Exception e)
        {
            Log.d("Ruby",e.toString());
        }
        holder.mTextView1.setText(currentItem.getItemName());
        holder.mTextView2.setText(currentItem.getDescription());
    }



    @Override
    public int getItemCount() { return mCardList.size();}
}