package com.Zdevelopors.ruby.ui.home;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.Zdevelopors.ruby.R;

@SuppressLint("Registered")
public class Hotel_card extends AppCompatActivity {
    private int RestaurantImage;
    private String RestaurantName;
    private String Tags;
    private float Rating;
    private int IsBookmarked;

    public Hotel_card(int restrauntImage, String restrauntName, String tags, Float rating,int isbookmarked)
    {
        RestaurantImage = restrauntImage;
        RestaurantName = restrauntName;
        Tags = tags;
        Rating = rating;
        IsBookmarked = isbookmarked;
    }

    public int getRestrauntImage() {
        return RestaurantImage;
    }

    public String getRestrauntName() {
        return RestaurantName;
    }

    public String getTags() {
        return Tags;
    }

    public float getRating() {
        return Rating;
    }

    public int getIsBookmarked(){return IsBookmarked;}

    public void IsBookmarked()
    {
        if(IsBookmarked == R.drawable.ic_bookmark_border_black_24dp)
            IsBookmarked = R.drawable.ic_bookmark_black_24dp;
        else
            IsBookmarked = R.drawable.ic_bookmark_border_black_24dp;
    }


}
