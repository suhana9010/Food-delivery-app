package com.Zdevelopors.ruby;

import android.annotation.SuppressLint;

import androidx.appcompat.app.AppCompatActivity;

@SuppressLint("Registered")
public class Item_Card extends AppCompatActivity {

    private int Veg_or_Nonveg;
    private String ItemName;
    private String Description;
    private int Cost;

    public Item_Card(int veg_or_Nonveg, String itemName,  int cost, String description) {
        Veg_or_Nonveg = veg_or_Nonveg;
        ItemName = itemName;
        Description = description;
        Cost = cost;
    }

    public int getVeg_or_Nonveg() {
        return Veg_or_Nonveg;
    }

    public String getItemName() {
        return ItemName;
    }

    public String getDescription() {
        return Description;
    }

    public int getCost() {
        return Cost;
    }
}
